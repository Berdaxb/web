<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="{{ route('product.index') }}">IZGE</a><br><br>
    <form action="{{ route('product.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <input type="text" name="name" value="{{ $product->name }}"><br><br>
        <input type="text" name="description" value="{{ $product->description }}"><br><br>
        <input type="number " name="price" value="{{ $product->price }}"><br><br>
        <input type="file" name="image"><br><br>
        <button>qosiw</button>
    </form>
</body>
</html>