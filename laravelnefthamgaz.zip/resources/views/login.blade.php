<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/brands.min.css" integrity="sha512-rQgMaFKZKIoTKfYInSVMH1dSM68mmPYshaohG8pK17b+guRbSiMl9dDbd3Sd96voXZeGerRIFFr2ewIiusEUgg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="main">
        <div class="container">
            <div class="form">
                <h2>Login</h2>
                <form action="{{ url('login') }}" method="POST">
                    @csrf
                    <input type="text" name="name" placeholder="Name" class="name">
                    <h1 class="name3">atinizdi jazin'</h1>
                    <input type="text" name="phone" placeholder="Phone" class="phone">
                    <h1 class="name2">tomendegi koriniste jazin': 99999999</h1>
                    <input type="text" name="password" placeholder="password" class="password">
                    <h1 class="name1">minimum 8 element boliwi kerek</h1>
                    <button class="button" onclick="basti()" type="submit">kiriw</button>
                </form>
            </div>
        </div>
    </div>
    <script src="script.js">
    </script>
</body>
</html>