<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::get();
        return view('admin.product', [
            'products' => $products
        ]);
    }

    public function create()
    {
        return view('admin.create');
    }
    
    public function store(StoreProductRequest $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'price' => 'numeric|required',
            'image' => 'mimes:png,jpg,jpeg,jfif|required|max:10000' 
         ]);
        $imageName = time().'.'.$request->image->getClientOriginalExtension();
        $request->image->move(public_path('/images'), $imageName);
        Product::create([
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
            'image' => 'images/'.$imageName
        ]);
        return redirect('product');
    }

    public function show($id)
    {
        $product = Product::find($id);
        return view('show', ['product' => $product]);
    }

    public function edit($id)
    {
        $product = Product::find($id);
        return view('admin.edit', [
            'product' => $product
        ]);
    }

    public function update(UpdateProductRequest $request, $id)
    {
        if(!isset($request->image))
        {
            $img_url = Product::where('id', $id)->get()[0]['image'];
        }
        else
        {
            $imageName = time().'.'.$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/images'), $imageName);
            $img_url = 'images/'.$imageName;
        }
        Product::find($id)->update([
           'name' => $request->name,
           'description' => $request->description,
           'price' => $request->price,
           'image' => $img_url 
        ]);
        return redirect('product');
    }

    public function destroy($id)
    {
        Product::find($id)->destroy($id);
        return back();
    }
}
