var a=document.querySelector('.name');
        var b=document.querySelector('.email');
        var c=document.querySelector('.pasword');
        var m=document.querySelector('.assa');
        function basti(){
            if(a.value.length>0)
            {
                if(b.value.length>=12)
            {
                if(c.value.length>=8)
            {
                d=b.value.split('');
                if(d[b.value.length-1]=='m' && d[b.value.length-2]=='o' && d[b.value.length-3]=='c' && d[b.value.length-4]=='.' && d[b.value.length-5]=='l' && d[b.value.length-6]=='i' && d[b.value.length-7]=='a' && d[b.value.length-8]=='m' && d[b.value.length-9]=='g' && d[b.value.length-10]=='@' ){
                    alert("siz registratsiyadan o'tiniz");
                    
                }
                else{
                    document.querySelector('.name2').style.display="block";
                }
            }
            else{
                document.querySelector('.name1').style.display="block";
            }
            }
            else{
                document.querySelector('.name2').style.display="block";
            }
            }
            else{
                document.querySelector('.name3').style.display="block";
            }
        }