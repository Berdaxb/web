<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('product.index')); ?>">IZGE</a><br><br>
    <form action="<?php echo e(route('product.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" name="name" value="<?php echo e($product->name); ?>"><br><br>
        <input type="text" name="description" value="<?php echo e($product->description); ?>"><br><br>
        <input type="number " name="price" value="<?php echo e($product->price); ?>"><br><br>
        <input type="file" name="image"><br><br>
        <button>qosiw</button>
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\laravelnefthamgaz\resources\views/admin/edit.blade.php ENDPATH**/ ?>