<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <title>Neft ham gaz qazip alıw úskeneleri</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-seo-dream.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">\

</head>

<body>
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <a href="<?php echo e(url('')); ?>" class="logo">
              <h4>NEFT HAM GAZ <img src="images/logo1.png" alt=""></h4>
            </a>
            <ul class="nav">
              <li class="scroll-to-section"><a href="#home" class="active">BAS BET</a></li>
              <li class="scroll-to-section"><a href="#equipment">QURILMALAR</a></li>
              <li class="scroll-to-section"><a href="#company">KOMPANIYALAR</a></li>
              <li class="scroll-to-section"><a href="#contact">BAYLANIS</a></li> 
              <li class="scroll-to-section"><div class="main-blue-button"><a href="">JIBERIW</a></div></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
          </nav>
        </div>
      </div>
    </div>
  </header>
  <section id="home" class="home">
    <div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="row">
              <div class="col-lg-6 align-self-center">
                <div class="left-content header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                  <div class="row">
                    <div class="col-lg-12">
                      <h2>NEFT &amp; GAZ QAZIP ALIW USKENELERI</h2>
                    </div>
                    <div class="col-lg-12">
                      <div class="main-green-button scroll-to-section">
                        <a href="#contact">baylanis</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                  <img src="assets/images/banner-right-image.png" alt="">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="equipment" class="equipment">
    <h2><center> NEFT HAM GAZ QURILMALARI </center></h2><br><br>
    <div id="features" class="features section">
      <div class="container>
        <div class="row">
          <div class="col-lg-12">
            <div class="features-content">
              <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                  <div class="features-item first-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
                    <div class="first-number number">
                      <h6><?php echo e($loop->iteration); ?></h6>
                    </div>
                    <a href="<?php echo e(route('product.show', $product->id)); ?>">
                    <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                      <img src="<?php echo e($product->image); ?>" alt="">
                    </div>
                    </a>
                    <h4><?php echo e($product->name); ?>

                    </h4>
                    <div class="line-dec"></div>
                    <h4><?php echo e($product->price); ?> $</h4>
                    </div>
                    <br>
                </div>
                <div class="col-lg-3">
                  <div class="skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                    <div class="progress" data-percentage="100">
                      <span class="progress-left">
                        <span class="progress-bar"></span>
                          </span>
                          <span class="progress-right">
                            <span class="progress-bar"></span>
                          </span>
                          <div class="progress-value">
                          <div>
                              100%<br>
                            <span>BARLIQ MAMLEKETLER</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <br><br>

  <section id="company" class="company">
    <h2><center>NEFT HAM GAZ KOMPANIYALARI</center></h2>
    <div id="about" class="about-us section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
              <img src="images/kompaniya1.png" alt="">
            </div>
          </div>
          <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <div class="section-heading">
              <h2>PetroChina</h2>
            </div>
            <div class="row">
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>750+</h4>
                  <h6>Joybarlar tamamlandi</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>340+</h4>
                  <h6>Baxıtlı klientler</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>128+</h4>
                  <h6>Sıylıqlar </h6>
                </div>
              </div>
            </div>
            <p><a rel="nofollow" href="https://ru.wikipedia.org/wiki/PetroChina" target="_parent">PetroChina</a> (Ch. PetroChina 1999 jıl noyabr ayında Kitaydıń CNPC mámleket kompaniyasınıń bir bólegi retinde islengen. CNPC ni qayta qurıw processinde islep shıǵarıw, qayta islew, neft-ximiya hám tábiy gaz ushın aktivler PetroChinaga ótkerildi. “PetroChina” kompaniyasınıń huqıqıy forması aksiyadorlik jámiyeti bolıp tabıladı. PetroChina kópshilik CNPCga tiyisli. Bas rezidenciyası Pekinda. Paydanıń 60% ten aslamı Kitaydan keledi. 2022 yilgi Forbes Global 2000 dúnyadaǵı eń iri kompaniyalar diziminde 21-orın (dáramat boyınsha 5-orın, sap dáramat boyınsha 56 -orın, aktivler boyınsha 104-orın hám bazar kapitallashuvi boyınsha 80-orın )</p>
            <div class="main-green-button"><a href="https://ru.wikipedia.org/wiki/PetroChina">Kompaniyada jańalıq ashıń </a></div>
          </div>
        </div>
      </div>
    </div>
    <div id="about" class="about-us section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
              <img src="images/kompaniya2.png" alt="">
            </div>
          </div>
          <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <div class="section-heading">
              <h2>Sinopec</h2>
            </div>
            <div class="row">
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>650+</h4>
                  <h6>Joybarlar tamamlandi</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>240+</h4>
                  <h6>Baxıtlı klientler</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>118+</h4>
                  <h6>Sıylıqlar </h6>
                </div>
              </div>
            </div>
            <p><a rel="nofollow" href="https://ru.wikipedia.org/wiki/Sinopec" target="_parent">Sinopec</a> China Petroleum & Chemical Corporation (" China Petroleum and Chemical Corporation", Sinopec Corp., Kitay shíngāngāngān, orıs Sinopec) - Kitaydıń integraciyalasqan energetika hám ximiya kompaniyası. Islep shıǵarıw kólemi boyınsha mámlekettiń ekinshi iri neft hám gaz kompaniyası (PetroChinadan keyin). Forbes Global 2000 2022 jıl ushın dúnyadaǵı eń iri kompaniyalar diziminde 45-orın (dáramat boyınsha 4-orın, sap dáramat boyınsha 79 -orın, aktivler boyınsha 146 -orın hám bazar kapitallashuvi boyınsha 174-orın )</p>
            <div class="main-green-button"><a href="https://ru.wikipedia.org/wiki/Sinopec">Kompaniyada jańalıq ashıń </a></div>
          </div>
        </div>
      </div>
    </div>
    <div id="about" class="about-us section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
              <img src="images/kompaniya3.png" alt="">
            </div>
          </div>
          <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <div class="section-heading">
              <h2>Saudi Aramco</h2>
            </div>
            <div class="row">
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>550+</h4>
                  <h6>Joybarlar tamamlandi</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>240+</h4>
                  <h6>Baxıtlı klientler</h6>
                </div>
              </div>
              <div class="col-lg-4 col-sm-4">
                <div class="about-item">
                  <h4>98+</h4>
                  <h6>Sıylıqlar </h6>
                </div>
              </div>
            </div>
            <p><a rel="nofollow" href="https://en.wikipedia.org/wiki/Saudi_Aramco" target="_parent">Saudi Aramco</a> (arab. ạ̉rạmkw ạlsʿwdyẗ ʾAramkū as-Suʿūdiyah), rásmiy atı Saudiya Araviyası neft kompaniyası (burınǵı Arab-Amerika neft kompaniyası ) yamasa ápiwayıǵana Aramco — Saudiya Araviyasınıń Dahronda jaylasqan mámleket neft hám tábiy gaz kompaniyası bolıp tabıladı[67][67]. ] 2020 jıl jaǵdayına kóre, ol dáramat boyınsha dúnyadaǵı eń iri kompaniyalardan biri esaplanadı.[8] Saudi Aramco 270 milliard barreldan artıq (43 milliard kub metr)[9] hám barlıq neft óndiriwshi kompaniyalar arasında eń úlken kúnlik neft qazib alıw boyınsha dúnyadaǵı ekinshi eń úlken tastıyıqlanǵan shiyki neft rezervlerine iye.[10][11]. Bul 1965 jıldan beri dúnyadaǵı hár qanday kompaniyanıń global uglerod emissiyasiga eń úlken úles qosatuǵın birden-bir kompaniya bolıp tabıladı.[12] 2022-jıl 11-mayda Saudi Aramco bazar ma`nisi boyınsha Apple Inc kompaniyasın artta qaldırıp, dúnyadaǵı eń iri (eń qımbatlı ) kompaniyaǵa aylandı.</p>
            <div class="main-green-button"><a href="https://en.wikipedia.org/wiki/Saudi_Aramco">Kompaniyada jańalıq ashıń </a></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="contact" class="contact">
    <div id="contact" class="contact-us section">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.25s">
            <form id="contact" action="" method="post">
              <div class="row">
                <div class="col-lg-6 offset-lg-3">
                  <div class="section-heading">
                    <h6></h6>
                    <h2>KOMPYUTER ILIMLERI HAM PROGRAMMALASTIRIW TEXNOLOGIYALARI</h2>
                  </div>
                  <div class="section-heading">
                  <h6>FAMILIYA: DUYSENBAEVA</h6>
                  <h6>ATI: SAHIBJAMAL</h6>
                  <h6>GRUPPA: 3-K1</h6>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="contact-info">
                    <ul>
                      <li>
                        <div class="icon">
                          <img src="assets/images/contact-icon-01.png" alt="email icon">
                        </div>
                        <a href="#">sahibjamal@gmail.com</a>
                      </li>
                      <li>
                        <div class="icon">
                          <img src="assets/images/contact-icon-02.png" alt="phone">
                        </div>
                        <a href="#">+99899 999 99 99</a>
                      </li>
                      <li>
                        <div class="icon">
                          <img src="assets/images/contact-icon-03.png" alt="location">
                        </div>
                        <a href="#">NUKUS KARAKALPAKSTAN</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>DUYSENBAEVA SAHIBJAMAL 
        
          <br>NUKUS KARSU 2022</p>
        </div>
      </div>
    </div>
  </footer>
  
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

</body>
</html><?php /**PATH C:\MAMP\htdocs\laravelnefthamgaz\resources\views/index.blade.php ENDPATH**/ ?>