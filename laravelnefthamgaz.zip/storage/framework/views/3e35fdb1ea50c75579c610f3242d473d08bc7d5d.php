<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">

    <title>SEO Dream - Creative SEO HTML5 Template by TemplateMo</title>

    <link href="<?php echo e(asset("vendor/bootstrap/css/bootstrap.min.css")); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset("assets/css/fontawesome.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/templatemo-seo-dream.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/animated.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/owl.css")); ?>">

</head>

<body>

  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>

  <div id="about" class="about-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
            <img src="<?php echo e(asset("assets/images/about-left-image.png")); ?>" alt="">
          </div>
        </div>
        <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
          <div class="section-heading">
            <h2><?php echo e($product->name); ?> <em><?php echo e($product->price); ?> $</em></h2>
          </div>
          <p><a rel="nofollow" href="https://templatemo.com/tm-563-seo-dream" target="_parent"></a> <?php echo e($product->description); ?></p>
          <div class="main-green-button"><a href="<?php echo e(url('')); ?>">IZGE QAYTIW</a></div>
        </div>
      </div>
    </div>
  </div>

  <script src="<?php echo e(asset("vendor/jquery/jquery.min.js")); ?>"></script>
  <script src="<?php echo e(asset("vendor/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/owl-carousel.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/animation.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/imagesloaded.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/custom.js")); ?>"></script>

</body>
</html><?php /**PATH C:\MAMP\htdocs\laravelnefthamgaz\resources\views/show.blade.php ENDPATH**/ ?>