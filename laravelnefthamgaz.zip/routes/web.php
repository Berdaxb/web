<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProductController;
use App\Models\Admin;
use App\Models\Product;
use Illuminate\Support\Facades\Route;



Route::get('/', function () {
    $products = Product::get();
    $admin = Admin::get();
    $count = count($admin);
    if($count == 0)
    {
        Admin::create([
            'name' => 'Sahibjamal',
            'phone' => '999999999',
            'password' => 'sahibjamal2022'
        ]);
    }
    return view('index', [
        'products' => $products
    ]);
});
Route::get('/admin', function(){
    return view('login');
});
Route::resource('product', ProductController::class);
Route::post('/login', [AdminController::class, 'store']);